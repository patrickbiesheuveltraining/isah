 
  
___________________________________________________________________

                    Companion CD Readme
                            for
         
           Microsoft Visual C# 2010 Step by Step
               by John Sharp (Content Master)

                  Copyright (c) 2010 
                      
   Portions copyright (c) 2010 by John Sharp (Content Master)
                            
                      All Rights Reserved


___________________________________________________________________


README CONTENTS
 - HOW TO USE THIS CD
   - AutoRun CD Menu
   - Electronic File Viewers
 - WHAT'S ON THIS CD?
 - SUPPORT INFORMATION
   - Microsoft Learning Technical Support
  

==================
HOW TO USE THIS CD
==================

---------------
AutoRun CD Menu
---------------
To use the CD, insert the CD in your CD-ROM drive. A menu screen
will appear. If AutoRun is not enabled (or AutoPlay on Windows Vista or later), 
run StartCD.exe at the root of the CD to display a start menu. This menu 
provides you with links to all the resources available on the CD and for 
accessing the Microsoft Press product support Web site.

-----------------------
Electronic File Viewers
-----------------------
The electronic version of the book and some of the other documentation 
included on this CD is provided in Portable Document Format (PDF). To view 
these files, you will need Adobe Acrobat or Adobe Reader. For more 
information about these products or to download the latest version of 
Adobe Reader, visit the Adobe Web site at http://www.adobe.com.


==================
WHAT'S ON THIS CD?
==================

This companion CD contains:

- Microsoft Visual C# 2010 Step by Step eBook
- Code Samples


-------------------------------------------
Microsoft Visual C# 2010 Step by Step eBook
-------------------------------------------
The complete text of the print book is contained on this CD in a
searchable PDF eBook. To view this eBook, open the PDF file in the
\eBook folder.
 
Note: The eBook is in Portable Document Format (PDF). To view this
file, you will need Adobe Acrobat or Adobe Reader. For more
information about these products or to download Adobe Reader,
visit the Adobe Web site at http://www.adobe.com.

------------
Code Samples
------------
The sample code files used in the book's examples are included on this CD.
To install them on your computer, click Install Code Samples and follow the 
instructions that appear.

To uninstall the sample code files, make the appropriate selection
from Add Or Remove Programs in Control Panel. For more information, 
see the book�s Introduction. 


===================
SUPPORT INFORMATION
===================

------------------------------------
Microsoft Learning Technical Support
------------------------------------
Every effort has been made to ensure the accuracy of the book 
and the contents of this CD. As corrections or changes are collected,
they will be added to a Microsoft Knowledge Base article. 
 
Microsoft Press provides support for books and companion CDs at
the following Web site: 

	http://www.microsoft.com/learning/support/books/

If you have comments, questions, or ideas regarding the book or this
CD, or questions that are not answered by visiting the site above,
please send them to Microsoft Press via e-mail to:

	mspinput@microsoft.com
    
Please note that Microsoft software product support is not offered 
through the above addresses.


==============================================================
DISCLAIMER: Third-Party Software or Links to Third-Party Sites
==============================================================
For the user's convenience, this CD may include third-party
software or links to third-party sites. 

Please note that these products are not under the control of
Microsoft Corporation and Microsoft is therefore not responsible
for their content, nor should their inclusion on this CD be
construed as an endorsement of the product. Please check
third-party Web sites for the latest version of their software.
